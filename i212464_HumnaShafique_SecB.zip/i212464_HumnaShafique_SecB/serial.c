#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <limits.h>
#include <omp.h>
#include <time.h> // Include for time functions

// Structure to represent each edge in the graph
struct Edge {
    int dest;
    int cost;
    struct Edge* next;
};

// Structure to represent each vertex in the graph
struct Node {
    struct Edge* adj;
};

// Function to create a new edge
struct Edge* newEdge(int dest, int cost) {
    struct Edge* newEdge = (struct Edge*)malloc(sizeof(struct Edge));
    newEdge->dest = dest;
    newEdge->cost = cost;
    newEdge->next = NULL;
    return newEdge;
}

// Function to add an edge to the graph
void addEdge(struct Node* graph, int src, int dest, int cost) {
    struct Edge* newE = newEdge(dest, cost);
    newE->next = graph[src].adj;
    graph[src].adj = newE;
}

// Function to find the shortest path between source and destination nodes using Bidirectional Dijkstra's algorithm
void findShortestPath(int n, struct Node* g, int src, int dest) {
    // Initialize distance arrays
    int* disSource = (int*)malloc((n + 1) * sizeof(int));
    int* disDest = (int*)malloc((n + 1) * sizeof(int));
    for (int i = 1; i <= n; i++) {
        disSource[i] = INT_MAX;
        disDest[i] = INT_MAX;
    }

    // Initialize priority queues
    typedef struct {
        int dist;
        int vertex;
    } Pair;
    Pair* pqSource = (Pair*)malloc((n + 1) * sizeof(Pair));
    Pair* pqDest = (Pair*)malloc((n + 1) * sizeof(Pair));
    int pqSizeSource = 0;
    int pqSizeDest = 0;

    pqSource[pqSizeSource++] = (Pair){0, src};
    pqDest[pqSizeDest++] = (Pair){0, dest};
    disSource[src] = 0;
    disDest[dest] = 0;

    // Bidirectional Dijkstra's algorithm
    while (pqSizeSource > 0 && pqSizeDest > 0) {
        // Forward search from source
        for (int i = 0; i < pqSizeSource; i++) {
            int u = pqSource[i].vertex;
            int d = pqSource[i].dist;

            // Relax edges from u
            for (struct Edge* e = g[u].adj; e != NULL; e = e->next) {
                int dest = e->dest;
                int cost = e->cost;

                if (disSource[u] + cost < disSource[dest]) {
                    disSource[dest] = disSource[u] + cost;
                    pqSource[pqSizeSource++] = (Pair){disSource[dest], dest};
                }
            }
        }

        // Backward search from destination
        for (int i = 0; i < pqSizeDest; i++) {
            int u = pqDest[i].vertex;
            int d = pqDest[i].dist;

            // Relax edges from u
            for (struct Edge* e = g[u].adj; e != NULL; e = e->next) {
                int dest = e->dest;
                int cost = e->cost;

                if (disDest[u] + cost < disDest[dest]) {
                    disDest[dest] = disDest[u] + cost;
                    pqDest[pqSizeDest++] = (Pair){disDest[dest], dest};
                }
            }
        }

        // Check for meeting point
        for (int i = 1; i <= n; i++) {
            if (disSource[i] != INT_MAX && disDest[i] != INT_MAX) {
                printf("Shortest path length between %d and %d is %d.\n", src, dest, disSource[i] + disDest[i]);
                free(disSource);
                free(disDest);
                free(pqSource);
                free(pqDest);
                return;
            }
        }
    }

    printf("No path found between %d and %d.\n", src, dest);

    // Free dynamically allocated memory
    free(disSource);
    free(disDest);
    free(pqSource);
    free(pqDest);
}

int main() {
    // Given Input
    int N = 36692, M = 367662;

    // Initialize graph
    struct Node* g = (struct Node*)malloc((N + 1) * sizeof(struct Node));
    for (int i = 1; i <= N; i++) {
        g[i].adj = NULL;
    }

    // Read edges from file
    FILE* file = fopen("graph.txt", "r");
    if (file == NULL) {
        printf("Error opening file.\n");
        exit(1);
    }

    int src, dest, cost;
    for (int i = 0; i < M; i++) {
        int readCount = fscanf(file, "%d %d", &src, &dest);
        if (readCount < 2) {
            printf("Invalid edge data in the file.\n");
            exit(1);
        }
        if (readCount == 2)
            cost = 1; // Default cost is 1 if not provided in the file
        else
            fscanf(file, "%d", &cost);

        addEdge(g, src, dest, cost);
    }
    fclose(file);

    // Prompt user to input source and destination nodes
    printf("Enter source node: ");
    scanf("%d", &src);
    printf("Enter destination node: ");
    scanf("%d", &dest);

    // Calculate execution time
    clock_t start_time = clock();

    // Function Call
    findShortestPath(N, g, src, dest);

    // Calculate and print execution time
    clock_t end_time = clock();
    double execution_time = (double)(end_time - start_time) / CLOCKS_PER_SEC;
    printf("Execution time: %f seconds\n", execution_time);

    // Free dynamically allocated memory
    for (int i = 1; i <= N; i++) {
        struct Edge* curr = g[i].adj;
        while (curr != NULL) {
            struct Edge* temp = curr;
            curr = curr->next;
            free(temp);
        }
    }
    free(g);

    return 0;
}

